# file: runme.py

import speak 

speak.start()
speak.speak("Hello, World!");
speak.stop()
