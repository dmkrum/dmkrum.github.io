# file: runme.py

import speak 


speak.start()  # to start up the TTS system

print "Volume: ", speak.getVolume()
print "Rate: ", speak.getRate()

speak.setVolume(75); # 0 to 100

speak.speak("Hello, world!");  # to say the string

speak.setRate(-10);  # -10 to 10

speak.speak("Very slow!");  # to say the string

speak.setRate(10);  # -10 to 10
speak.speak("Now, very fast talking!");  # to say the string


print "Number of voices: ", speak.getNumVoices()
speak.setRate(0);  # -10 to 10

for i in range(0,speak.getNumVoices()):
    speak.setVoice(i)
    buffer="Voice number "+str(i)
    print buffer
    speak.speak(buffer)

# The voice names can be found by going to the control panel.
# The speech control panel has a Text To Speech tab listing 
# all the different voices.

print "Microsoft Mike"
speak.setVoiceName("Microsoft Mike")
speak.speak("Microsoft Mike")

print "Microsoft Sam"
speak.setVoiceName("Microsoft Sam")
speak.speak("Microsoft Sam")

print "Microsoft Mary"
speak.setVoiceName("Microsoft Mary")
speak.speak("Microsoft Mary")

speak.stop()  # to close down the TTS system
